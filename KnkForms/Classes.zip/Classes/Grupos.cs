﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KnkForms.Classes
{
    public class Grupos:Pai
    {
        public string NomeGrupo { get; set; }
        public bool Ativo {  get; set; }
    }
}
