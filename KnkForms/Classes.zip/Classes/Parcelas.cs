﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KnkForms.Classes
{
    public class Parcelas:FormaPagamentos
    {
        public int Quantidade { get;set; }
        public float Valor { get;set; }
    }
}
